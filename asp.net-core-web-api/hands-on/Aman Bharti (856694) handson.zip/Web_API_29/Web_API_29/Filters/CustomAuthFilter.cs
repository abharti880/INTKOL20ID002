﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Web_API_29.Filters
{
    public class CustomAuthFilter: ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var x=context.HttpContext.Request.Headers.FirstOrDefault(p => p.Key.Equals("Authorization"));
            if (x.Key == null)
                throw new BadRequestObjectResult("Invalid");

            





        }

       
    }
}
