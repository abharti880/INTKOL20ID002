﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_API_29.Filters;
using Web_API_29.Models;

namespace Web_API_29.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CustomAuthFilter]
    public class EmployeeController : ControllerBase
    {
        private static List<Employee> list = new List<Employee>()
        {
            new Employee{Id=101,Name="Sujoy",Salary=10800,Permanent=true},
            new Employee{Id=102,Name="Pritam",Salary=15900,Permanent=true}
        };

        public IEnumerable<Employee> GetStandardEmployeeList()
        {
            return list;
        }

        // GET: api/Employee
        [HttpGet]
        [ProducesResponseType(200)]
        public IEnumerable<Employee> Get()
        {
            var emp=GetStandardEmployeeList();
            return emp;
            

        }

        // GET: api/Employee/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Employee
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
