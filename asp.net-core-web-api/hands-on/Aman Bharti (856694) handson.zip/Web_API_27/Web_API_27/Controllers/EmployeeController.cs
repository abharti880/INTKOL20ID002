﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_API_27.Models;

namespace Web_API_27.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        public static List<Employee> lst = new List<Employee>
        {
            new Employee{Id=1,Name="Sujoy",Permanent=true,Salary=9000},
            new Employee{Id=2,Name="Pritam",Permanent=false,Salary=10000}
        };
        
        
        // GET: api/Employee
        //[Authorize]
        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return lst;
            
        }

        // GET: api/Employee/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Employee
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
