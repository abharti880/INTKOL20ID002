﻿namespace Web_API_30.Controllers
{
    public class Employee
    {
        public int Id { get; set; }
        public string  Name { get; set; }
    }
}