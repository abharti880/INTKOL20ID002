﻿1) From postman 
http://localhost:59674/api/authenticate
Post request

Authentication: Basic
username: awesome-username
password: awesome-password

Will receive jwt token copy that

2) http://localhost:59674/api/values
Get Request

Authorization Header: paste the jwt token with out quotes
jwt token: 
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYmYiOjE1NzYwNDU3MzUsImV4cCI6MTU3NjA0OTMzNSwiaWF0IjoxNTc2MDQ1NzM1LCJpc3MiOiJodHRwczovL2F3ZXNvbWUuaW8iLCJhdWQiOiJodHRwczovL2FwcC5hd2Vzb21lLmlvIn0.HqzHXGK3OCKM0fSwjiX9qXxyqBEAkKJJyH92dt7h2vY


