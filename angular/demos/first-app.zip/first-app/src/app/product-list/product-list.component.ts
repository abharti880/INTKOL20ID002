import { Component, OnInit } from '@angular/core';
import { ProductType } from './product-type';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
proudtList:ProductType[]=[
  new ProductType(1,"pen",25),
  new ProductType(2,"Pencil",5),
  new ProductType(3,"Eraser",5)
];
  constructor() { }

  ngOnInit(): void {
  }

}
