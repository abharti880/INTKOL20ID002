import { Component } from '@angular/core';


@Component(
    {
        selector:'employee',
        templateUrl:'./employee.component.html'
    }
)
export class EmployeeComponent{
    id:number=1;
    name:string="Prakash";
    email:string="Prakash.Venigandla@cognizant.com";
}